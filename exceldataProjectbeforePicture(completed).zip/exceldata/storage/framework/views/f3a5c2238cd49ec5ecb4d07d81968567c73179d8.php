<?php echo $__env->make('flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
	<?php if(session('status')): ?>
        <div class="alert alert-success">
           <?php echo e(session('status')); ?>                   
        </div>
    <?php endif; ?>
    <script>
            $(document).ready(function() {
            $('a[data-confirm]').click(function(ev) {
            var href = $(this).attr('href');
            if (!$('#dataConfirmModal').length) {
            $('body').append('<div id="dataConfirmModal" class="modal fade modal" role="dialog" aria-labelledby="dataConfirmLabel" aria-hidden="true"><div class="modal-dialog "><div class="modal-content"><div class=" modal-header" ><button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button><h3 id="dataConfirmLabel" >Please Confirm</h3></div><div class="modal-body"></div><div class="modal-footer"><button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button><a class="btn btn-danger" id="dataConfirmOK">Delete</a></div></div></div></div>');
            } 
            $('#dataConfirmModal').find('.modal-body').text($(this).attr('data-confirm'));
            $('#dataConfirmOK').attr('href', href);
            $('#dataConfirmModal').modal({show:true});
            return false;
                });
        });
    </script>
    <div id="app">
    <div class="container" >
    <a href="http://eventsdatabase.mwancloud.com/home" class="btn btn-default">HOME PAGE</a>
    
        <div class="text-center">
            <h1 style="color:green;"><?php echo e($record->first_name); ?>  <?php echo e($record->sur_name); ?>   Record</h1>
        </div>
        <div>
        <a href="javascript:history.back();" class="btn btn-default">Go Back</a>
        
        <div style="float:right;">
        <a href="<?php echo e(url('editing/'.$record->id)); ?>" class="btn btn-warning">Edit</a> 
        <a href="<?php echo e(url('deletesingle/'.$record->id)); ?>" data-confirm="Are you sure you want to delete?" class="btn btn-danger">Delete</a>
        </div>
        </div>
        
        <fieldset class="col-md-12" style="background-color:#fff; margin-top:20px;">    	
        <legend>Personal Info</legend>
        <div class="col-md-12 col-lg-12 col-sm-12">    
            <div class="form-group row">
                <div class="col-md-4">
                    <div class="p-3 mb-2 bg-success text-white">  <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Title')); ?>    :</label>
                        <?php echo e($record->title); ?>

                    </div>
                    <br>
                    <div class="p-3 mb-2 bg-success text-white"> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('First Name')); ?>    :</label>
                        <?php echo e($record->first_name); ?> 
                    </div>
                    <br>
                    <div class="p-3 mb-2 bg-success text-white"> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Surname')); ?>   :</label>
                        <?php echo e($record->sur_name); ?>

                    </div>
                    <br>

                    <div class="p-3 mb-2 bg-success text-white"> <label for="title" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Middle Name')); ?>    :</label>
                         <?php echo e($record->middle_name); ?>

                    </div>

                </div>

                <div class="col-md-4 ">
                    <div class="p-3 mb-2 bg-success text-white"> <label for="position" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Position')); ?>    :</label>
                        <?php echo e($record->position); ?> 
                    </div>
                    <br>
                    <div class="p-3 mb-2 bg-success text-white"> <label for="company" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Company')); ?>    :</label>
                        <?php echo e($record->company); ?> 
                    </div>
                    <br>
                    <div class="p-3 mb-2 bg-success text-white"> <label for="department" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Department')); ?>    :</label>
                        <?php echo e($record->department); ?>

                    </div>

                </div>

               
                <div class="col-md-4">
                    <div class="p-3 mb-2 bg-success text-white">  <label for="age_group" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('AGE Group')); ?>    :</label>
                        <?php echo e($record->age_group); ?>

                    </div> 
                    <br>
                    <div class="p-3 mb-2 bg-success text-white">  <label for="gender" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Gender')); ?>    :</label>
                        <?php echo e($record->gender); ?>

                    </div>
                    <br>
                    <div class="p-3 mb-2 bg-success text-white">  <label for="nationality" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Nationality')); ?>    :</label>
                        <?php echo e($record->nationality); ?>

                    </div>
                    <br>
                </div>

              

            </div>
        </div>
    </fieldset>	
    <fieldset class="col-md-12" style="background-color:#fff; margin-top:20px;">    	
        <legend>Contact Info</legend>
        
        <div class="col-md-12 col-lg-12 col-sm-12">
                <div class="form-group row">
                    <div class="col-md-4">
                        <div class="p-3 mb-2 bg-info text-white"> <label for="address1" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Address1')); ?>    :</label>
                            <br> <?php echo e($record->address1); ?>

                        </div>
                         <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="address2" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Address2')); ?>    :</label>
                           <br> <?php echo e($record->address2); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="city" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('City')); ?>    :</label>
                            <?php echo e($record->city); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="post_code" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Postcode')); ?>    :</label>
                            <?php echo e($record->post_code); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="state" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('State')); ?>    :</label>                  
                            <?php echo e($record->state); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="country" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Country')); ?>    :</label>
                             <?php echo e($record->country); ?>

                        </div>

                    </div>
                
                    <div class="col-md-4 ">
                        <div class="p-3 mb-2 bg-info text-white"><label for="telephone_country" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Country Code')); ?>    :</label>
                             <?php echo e($record->telephone_country); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="telephone" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Telephone')); ?>    :</label>
                            <?php echo e($record->telephone); ?> 
                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="extention" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Extention')); ?>    :</label>
                            <?php echo e($record->extention); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="telephone_country_2" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Country Code (2)')); ?>    :</label>
                            <?php echo e($record->telephone_country_2); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"> <label for="telephone_2" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Telephone (2)')); ?>    :</label>
                            <?php echo e($record->telephone_2); ?>  
                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"> <label for="extention_2" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Extention (2)')); ?>    :</label>
                        <?php echo e($record->extention_2); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="facsimile_country" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Fax Country Code')); ?>    :</label>
                        <?php echo e($record->facsimile_country); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="facsimile" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Fax No.')); ?>    :</label>
                        <?php echo e($record->facsimile); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="mobile_area" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Country Code')); ?>    :</label>
                            <?php echo e($record->mobile_area); ?> 
                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="mobile_number" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Mobile Number')); ?>    :</label>
                            <?php echo e($record->mobile_number); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="mobile_area_2" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Country Code (2)')); ?>    : </label>
                            <?php echo e($record->mobile_area_2); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="mobile_number_2" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Mobile Number (2)')); ?>    :</label>
                        <?php echo e($record->mobile_number_2); ?>

                        </div>
                        

                    </div>
                    <div class="col-md-4 ">
                        <div class="p-3 mb-2 bg-info text-white"> <label for="email_work" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Email Work')); ?>    :</label>
                            <?php echo e($record->email_work); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="email_private" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Private Email')); ?>    :</label>
                             <?php echo e($record->email_private); ?>

                         </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="email" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Email')); ?>    :</label>
                            <?php echo e($record->email); ?>

                        </div>
                        <br>
                        <div class="p-3 mb-2 bg-info text-white"><label for="company_website" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Company Website')); ?>    :</label>
                            <?php echo e($record->company_website); ?>

                        </div>
                            
                    </div>
               </div>
        </div>
    </fieldset>	
    <fieldset class="col-md-12" style="background-color:#fff; margin-top:20px;">    	
        <legend>Event Info</legend>
        <div class="col-md-12 col-lg-12 col-sm-12">
            
            <div class="form-group row">
                <div class="col-md-4">
                <div class="p-3 mb-2 bg-success text-white"><label for="category" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Category')); ?>    :</label>
                   <?php echo e($record->category); ?>

                </div>
                   <br>
                   <div class="p-3 mb-2 bg-success text-white"><label for="event_id" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Event ID')); ?>    :</label>
                    <?php echo e($record->event_id); ?>

                    
                    </div>
                    
                   
                </div>
                 
                <div class="col-md-4 ">
                <div class="p-3 mb-2 bg-success text-white"><label for="event_name" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Event Name')); ?>    :</label>
                    <?php echo e($record->event_name); ?>

                    </div>
                    <br> 
                <div class="p-3 mb-2 bg-success text-white"><label for="event_date" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Event Date')); ?>    :</label>
                    <?php echo e($record->event_date); ?>

                    </div>
                    <br>
                    <div class="p-3 mb-2 bg-success text-white"> <label for="event_place" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Event Place')); ?>    :</label>
                    <?php echo e($record->event_place); ?>

                    </div>
                </div>

                <div class="col-md-4 ">
                     <div class="p-3 mb-2 bg-success text-white"> <label for="history_mwan_events_attend" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Events History')); ?>    :</label>
                        <?php echo e($record->history_mwan_events_attend); ?>

                    </div>
                </div>
                
            </div>
        </div>
    </fieldset>
    <fieldset class="col-md-12" style="background-color:#fff; margin-top:20px;">    	
        <legend>Subscribes</legend>
         <div class="col-md-12 col-lg-12 col-sm-12">
                <div class="form-group row">

                   <div class="col-md-6">
                   <div class="p-3 mb-2 bg-success text-white"><label for="maretingoptns" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('MARKETING OPT-INS')); ?>    :</label>
                   <?php echo e($record->maretingoptns); ?>

                  
                   </div>
                  
                </div>

                <div class="col-md-6">
                    <div class="p-3 mb-2 bg-success text-white"><label for="unsubscribes" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Subscribes News')); ?>    :</label>
                  
                    <?php echo e($record->unsubscribes); ?>

                    </div>
                   
                </div> 
                    
                
                    
               </div>
        </div>
        <div class="col-md-12 col-lg-12 col-sm-12">
                <div class="form-group row">

                   <div class="col-md-6">
                        <div class="p-3 mb-2 bg-success text-white"> <label for="opt_in" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Date Opts-in')); ?>    :</label>
                        <?php echo e($record->opt_in); ?>

                    
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="p-3 mb-2 bg-success text-white"><label for="opt_out" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Date Opts-out')); ?>    :</label>
                        <?php echo e($record->opt_out); ?>

                    
                        <div>
                    </div> 

                    <!-- <div class="col-md-4">
                        <div class="p-3 mb-2 bg-success text-white"><label for="neutral" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Date Neutral')); ?>    :</label>
                        <?php echo e($record->neutral); ?>

                    
                        </div> -->
                    </div> 
               </div>
        </div>
        </div>

          <div class="col-md-12 col-lg-12 col-sm-12">
            
            <div class="form-group row">
                <div class="col-md-12 ">
                    <div class="p-3 mb-2 bg-success text-white"><label for="comments" style="margin-top: 5px;margin-left: 10px;"><?php echo e(__('Comments')); ?>    :</label>
                    
                     <?php echo e($record->comments); ?>

                    </div>
                </div>

            </div>
        </div>
        
    </fieldset>

        
        <!-- <div class="col-md-12 col-lg-12 col-sm-12" style="background-color:white; font-size:18px;">    
         
            <div class="form-group row">
                <div class="col-md-3">  
                        <div class="text-center">
                            <h3 style="color:green;"><b>Personer Info</b></h3>
                        </div>
                        <hr>
                    <span >
                    
                       <b>Title: </b><br><?php echo e($record->title); ?><br>
                       <b>First Name   : </b><br> <?php echo e($record->first_name); ?> <br>
                       <b> Middle Name : </b><br> <?php echo e($record->sur_name); ?><br>
                       <b>Surname : </b><br> <?php echo e($record->middle_name); ?><br>
                       <b> Position : </b><br> <?php echo e($record->position); ?> <br>
                       <b>Department : </b><br><?php echo e($record->department); ?> <br>
                       <b>Company : </b><br> <?php echo e($record->company); ?> <br>
                       <b>Age Group :  </b><br> <?php echo e($record->age_group); ?><br>
                       <b>Nationality : </b><br><?php echo e($record->nationality); ?><br>
                       <b>Nature Of Business : </b><br>  <?php echo e($record->nature_of_business); ?><br>
                    </span>
                   
                    
                </div>

                <div class="col-md-6">  
                    <div class="text-center">
                        <h3 style="color:green;"><b>Contact Info</b></h3>
                    </div>
                    <hr>
                   
                   
                    <div class="col-md-6">  
                    <b>Address1:</b><br><?php echo e($record->address1); ?><br>
                    <b>City:</b><br> <?php echo e($record->city); ?><br>
                    <b>Country:</b><br><?php echo e($record->country); ?><br>
                    <b>Telephone:</b><br><?php echo e($record->telephone_country); ?>-<?php echo e($record->telephone); ?> :<b> Ext:</b>  <?php echo e($record->extention); ?><br>
                    <b>Fax :</b><br><?php echo e($record->facsimile_country); ?>-<?php echo e($record->facsimile); ?><br>
                    <b>Mobile No. :</b><br><?php echo e($record->mobile_area); ?>- <?php echo e($record->mobile_number); ?><br>
                    <b>Email Work :</b><br><?php echo e($record->email_work); ?><br>
                    <b>Private Email :</b><br><?php echo e($record->email_private); ?><br>
                    </div>
                    <div class="col-md-6">  
                    <b>Address2:</b><br><?php echo e($record->address2); ?><br>
                    <b>State:</b><br><?php echo e($record->state); ?><br>
                    <b>Postcode:</b><br><?php echo e($record->post_code); ?><br>
                    <b>Telephone 2:</b><br><?php echo e($record->telephone_country_2); ?>-<?php echo e($record->telephone_2); ?>:<b> Ext:</b>  <?php echo e($record->extention); ?><br>
                    <b>Mobile No. :</b><br><?php echo e($record->mobile_area_2); ?>- <?php echo e($record->mobile_number_2); ?><br>
                    
                    <b>Email :</b><br><?php echo e($record->email); ?><br>
                    <b>Company Website :</b><br> <?php echo e($record->company_website); ?><br>
                    </div>  
                </div>

                <div class="col-md-3">  
                    <div class="text-center">
                        <h3 style="color:green;"><b>Event Info</b></h3>
                    </div>
                    <hr>
                   <b>Category:</b><br> <?php echo e($record->category); ?><br>
                   <b>Event_id:</b><br> <?php echo e($record->event_id); ?><br>
                   <b>Event_id:</b> <br> <?php echo e($record->event_id); ?><br>
                   <b>Event_date:</b><br>  <?php echo e($record->event_date); ?><br>
                   <b>Event_place:</b><br> <?php echo e($record->event_place); ?><br>
                    <div class="text-center">
                        <h3 style="color:green;"><b>Subscription</b></h3>
                        <hr>
                    </div>
                    <b>maretingoptns:</b><br>  <?php echo e($record->maretingoptns); ?>

                    <b>opt_in:</b> <br> <?php echo e($record->opt_in); ?>

                    <b>opt_out:</b><br>  <?php echo e($record->opt_out); ?>

                    <b>neutral:</b><br> <?php echo e($record->neutral); ?>

                    <b>history_mwan_events_attend:</b><br> <?php echo e($record->history_mwan_events_attend); ?>

                    <b>comments:</b><br> <?php echo e($record->comments); ?>

                    <b>Subscribes:</b> <br> <?php echo e($record->unsubscribes); ?>

                </div>
            </div>
        </div> -->
    </div>
</div>
 <?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>