<?php echo $__env->make('flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
<div class="alert alert-success">
<?php echo e(session('status')); ?>

</div>
<?php endif; ?>


<?php if(Auth::check()): ?> 
    <div class="container">
        <a href="http://eventsdatabase.mwancloud.com/home" class="btn btn-default">HOME PAGE</a>

        <!-- javaScript delete confirmation -->
        <script>
            $(document).ready(function() {
            $('a[data-confirm]').click(function(ev) {
            var href = $(this).attr('href');
            if (!$('#dataConfirmModal').length) {
            $('body').append('<div id="dataConfirmModal" class="modal fade modal" role="dialog" aria-labelledby="dataConfirmLabel" aria-hidden="true"><div class="modal-dialog "><div class="modal-content"><div class=" modal-header" ><button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button><h3 id="dataConfirmLabel" >Please Confirm</h3></div><div class="modal-body"></div><div class="modal-footer"><button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button><a class="btn btn-danger" id="dataConfirmOK">Delete</a></div></div></div></div>');
            } 
            $('#dataConfirmModal').find('.modal-body').text($(this).attr('data-confirm'));
            $('#dataConfirmOK').attr('href', href);
            $('#dataConfirmModal').modal({show:true});
            return false;
                });
        });
        </script>
        <!-- End JavaScript code -->
        <div class="text-center">
        <h4> Customer search </h4>
        </div>
        
        <section>
            <form method="POST"  action="<?php echo e(route('searchname')); ?>">
               <?php echo e(csrf_field()); ?>

                <div class="col-md-12 col-lg-12 col-sm-12">
                    <div class="form-group row">
                        <div class="col-md-3">
                       
                            <input id="first_name" type="text" placeholder="Seach by First Name " class="form-control<?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>" name="first_name" value="<?php echo e(old('first_name')); ?>" >
                            <?php if($errors->has('first_name')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('first_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div>
                       
                            <button type="submit" class="btn btn-success">
                                <?php echo e(__('SEARCH')); ?>

                            </button>
                        </div>
                    </div>
                </div>  
            </from>
        </section>

            <h1>Show Record</h1>
           
        <div class="table-responsive " >
            <table class="table table-bordered table-striped table-hover">

            <thead bgcolor="#fff" >
                                                    <tr>
                                                        <th>Title</th>
                                                        <th>First Name</th>
                                                        <th>Middle Name</th>
                                                        <th>SurName</th>
                                                        <th>Position</th>
                                                        <th>Departement</th>
                                                        <th>Company</th>
                                                        <th>Address1</th>
                                                        <th>Address2</th>
                                                        <th>City</th>
                                                        <th>Post Code</th>
                                                        <th>State</th>
                                                        <th>Country</th>
                                                        <th>Telephone Country</th>
                                                        <!-- <th>Area Code</th> -->
                                                        <th>Telephone</th>
                                                        <th>Extension</th>
                                                        <th>Facsimile Country</th>
                                                        <!-- <th>Facsimile Area</th> -->
                                                        <th>Facsimile</th>
                                                        <th>Mobile Country</th>
                                                        <th>Mobile Number</th>
                                                        <th>Mobile Country(2)</th>
                                                        <th>MObile Number (2)</th>
                                                        <th>Email Work</th>
                                                        <th>Private Email</th>
                                                        <th>Email</th>
                                                        <th>Company Website</th>
                                                        <th>Age Group</th>
                                                        <th>Nationality</th>
                                                        <th>Nature of Business</th>
                                                        <th>Category</th>
                                                        <th>Event ID</th>
                                                        <th>Event Name</th>
                                                        <th>Event Date</th>
                                                        <th> Mareting OPT-INS</th>
                                                        <!-- <th>Event History</th> -->
                                                        <th>Comments</th>
                                                        <th>Unsubscribes</th>
                                                        <th>Actions </th>
                                                    
                                                    </tr>
            </thead>
            <tbody bgcolor="#fff">
     
                                                 
            <?php if(count($record ) > 0): ?>
                <?php $__currentLoopData = $record; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td> <?php echo e($post->title); ?></td>
                        <td> <?php echo e($post->first_name); ?></td>
                        <td> <?php echo e($post->middle_name); ?></td>
                        <td> <?php echo e($post->sur_name); ?></td>
                        <td><?php echo e($post->position); ?> </td>
                        <td><?php echo e($post->department); ?> </td>
                        <td><?php echo e($post->company); ?> </td>
                        <td> <?php echo e($post->address1); ?></td>
                        <td> <?php echo e($post->address2); ?></td>
                        <td> <?php echo e($post->city); ?></td>
                        <td> <?php echo e($post->post_code); ?></td>
                        <td> <?php echo e($post->state); ?></td>
                        <td> <?php echo e($post->country); ?></td>
                        <td> <?php echo e($post->telephone_country); ?></td>
                        <!-- <td> <?php echo e($post->telephone_area); ?></td> -->
                        <td> <?php echo e($post->telephone); ?></td>
                        <td> <?php echo e($post->extention); ?></td>
                        <td> <?php echo e($post->facsimile_country); ?></td>
                        <!-- <td> <?php echo e($post->facsimile_area); ?></td> -->
                        <td> <?php echo e($post->facsimile); ?></td>
                        <td> <?php echo e($post->mobile_area); ?></td>
                        <td> <?php echo e($post->mobile_number); ?></td>
                        <td> <?php echo e($post->mobile_area_2); ?></td>
                        <td> <?php echo e($post->mobile_number_2); ?></td>
                        <td> <?php echo e($post->email_work); ?></td>
                        <td> <?php echo e($post->email_private); ?></td>
                        <td> <?php echo e($post->email); ?></td>
                        <td> <?php echo e($post->company_website); ?></td>
                        <td> <?php echo e($post->age_group); ?></td>
                        <td> <?php echo e($post->nationality); ?></td>
                        <td> <?php echo e($post->nature_of_business); ?></td>
                        <td> <?php echo e($post->category); ?></td>
                        <td> <?php echo e($post->event_id); ?></td>
                        <td> <?php echo e($post->event_name); ?></td>
                        <td> <?php echo e($post->event_date); ?></td>
                        <td> <?php echo e($post->maretingoptns); ?></td>
                        <!-- <td> <?php echo e($post->history_mwan_events_attend); ?></td> -->
                        <td><?php echo e($post->comments); ?></td>
                        <td><?php echo e($post->unsubscribes); ?></td>
                        <td>
                            <a href="<?php echo e(url('editing/'.$post->id)); ?>" class="btn btn-link">Edit</a> 
                          
                            <a href="<?php echo e(url('delete/'.$post->id)); ?>" data-confirm="Are you sure you want to delete?" class="btn btn-danger">Delete</a>
                            
                        </td>
                     
                        
                        </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <p>No posts found</p>
            <?php endif; ?>

            </tbody>

            </tbody>


            </table>
        </div>

                 

    </div>


<?php else: ?>
<div>You need to Login to perfrom some actions</div>
<?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>