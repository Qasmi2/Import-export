<?php echo $__env->make('flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
						<?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            
                            </div>
                        <?php endif; ?>
<!-- <div>You need to Login to perfrom some actions</div> -->
<div class="container">
    <!-- <a href="http://localhost:8080/exceldata/public/home" class="btn btn-default">HOME PAGE</a> -->
	<br/><br/>
	<?php if(Auth::check()): ?> 
	  
		
			<a href="<?php echo e(URL::to('downloadexcel/xls')); ?>"><button class="btn btn-success">Download Excel xls</button></a>
			<a href="<?php echo e(URL::to('downloadexcel/xlsx')); ?>"><button class="btn btn-success">Download Excel xlsx</button></a>

	
			<a href="<?php echo e(URL::to('downloadexcel/csv')); ?>"><button class="btn btn-success">Download CSV</button></a>
		
			<form style="border: 5px solid #2ab27b;margin-top: 15px;padding: 15px;" action="<?php echo e(URL::to('importexcel')); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>

			
			<label>Please choose a CSV file</label>
				<input type="file" name="import_file" class="btn btn-success"/>
				<br/>
				<button class="btn btn-success">Import File</button>
			</form>
		</div>
	<?php else: ?>
	
		<div>You need to Login to perfrom some actions</div>
	
	<?php endif; ?>
	
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>