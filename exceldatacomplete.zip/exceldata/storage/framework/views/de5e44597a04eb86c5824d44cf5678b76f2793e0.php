<?php echo $__env->make('flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
             <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>



    <div id="app">
        <div class="container">
        <a href="http://eventsdatabase.mwancloud.com/home" class="btn btn-default">HOME PAGE</a>
            <div class="text-center">
                <h1>CUMSTOM SEARCH</h1>
            </div>
            <!-- searching form -->
            <form method="POST"  action="<?php echo e(route('searchname')); ?>">
                <?php echo e(csrf_field()); ?>

                <!-- searching by Name -->
                <div class="col-md-12 col-lg-12 col-sm-12">
                    <div class="form-group row">
                        <div class="col-md-10">
                        <label for="title"><?php echo e(__('SEARCH BY FIRST NAME')); ?></label>
                            <input id="first_name" type="text" placeholder="Seach by First Name " class="form-control<?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>" name="first_name" value="<?php echo e(old('first_name')); ?>" >
                            <?php if($errors->has('first_name')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('first_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-2" style="margin-top: 23px;">
                       
                            <button type="submit" class="btn btn-lg btn-success disabled">
                                <?php echo e(__('SEARCH')); ?>

                            </button>
                        </div>
                    </div>
                 </div>         
                 <!-- searching by Email -->
                 <div class="col-md-12 col-lg-12 col-sm-12">
                    <div class="form-group row">
                        <div class="col-md-10">
                        <label for="email"><?php echo e(__('SEARCH BY Email')); ?></label>
                            <input id="email" type="text" placeholder="Seach by Email " class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" >
                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-2" style="margin-top: 23px;">
                       
                            <button type="submit" class="btn btn-lg btn-success">
                                <?php echo e(__('SEARCH')); ?>

                            </button>
                        </div>
                    </div>
                 </div>    
                    <!-- search by Event Name -->
                 <div class="col-md-12 col-lg-12 col-sm-12">
                    <div class="form-group row">
                        <div class="col-md-10">
                        <label for="event_name"><?php echo e(__('SEARCH By Event_Name')); ?></label>
                            <input id="event_name" type="text" placeholder="Seach event_name " class="form-control<?php echo e($errors->has('event_name') ? ' is-invalid' : ''); ?>" name="event_name" value="<?php echo e(old('event_name')); ?>" >
                            <?php if($errors->has('event_name')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('event_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-2" style="margin-top: 23px;">
                       
                            <button type="submit" class="btn btn-lg btn-success disabled">
                                <?php echo e(__('SEARCH')); ?>

                            </button>
                        </div>
                    </div>
                 </div>  
                  <!-- search by every ID -->
                  <div class="col-md-12 col-lg-12 col-sm-12">
                    <div class="form-group row">
                        <div class="col-md-10">
                        <label for="event_id"><?php echo e(__('SEARCH By Event_ID')); ?></label>
                            <input id="event_id" type="text" placeholder="Seach by event_ID " class="form-control<?php echo e($errors->has('event_id') ? ' is-invalid' : ''); ?>" name="event_id" value="<?php echo e(old('event_id')); ?>" >
                            <?php if($errors->has('event_id')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('event_id')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-2" style="margin-top: 23px;">
                       
                            <button type="submit" class="btn btn-lg btn-success">
                                <?php echo e(__('SEARCH')); ?>

                            </button>
                        </div>
                    </div>
                 </div>  
                <!-- searching by country and company -->
                <div class="text-center" style="margin:30px;">
                
                    <h3 >Country and Position  SEARCH</h3>
                 </div>
                
                <div class="col-md-12 col-lg-12 col-sm-12">
                    <div class="form-group row">
                        <div class="col-md-5">
                        <label for="country"><?php echo e(__('SEARCH Country and Position')); ?></label>
                            <input id="country" type="text" placeholder="Enter Country " class="form-control<?php echo e($errors->has('country') ? ' is-invalid' : ''); ?>" name="country" value="<?php echo e(old('country')); ?>" >
                            <?php if($errors->has('country')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('country')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-5">
                        <label for="position"><?php echo e(__('SEARCH Country and Position')); ?></label>
                            <input id="position" type="text" placeholder="Enter position " class="form-control<?php echo e($errors->has('position') ? ' is-invalid' : ''); ?>" name="position" value="<?php echo e(old('position')); ?>" >
                            <?php if($errors->has('position')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('position')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-2" style="margin-top: 23px;">
                       
                            <button type="submit" class="btn btn-lg btn-success">
                                <?php echo e(__('SEARCH')); ?>

                            </button>
                        </div>
                    </div>
                 </div>  
                <!-- searching event Name and first name -->
                
                <div class="text-center" style="margin:30px;">
                
                    <h3 >First Name and Event Name  SEARCH</h3>
                 </div>
                <div class="col-md-12 col-lg-12 col-sm-12">
                    <div class="form-group row">
                        <div class="col-md-5">
                        <label for="first_name"><?php echo e(__('SEARCH first Name and Event ID')); ?></label>
                            <input id="first_name" type="text" placeholder="Enter first_name " class="form-control<?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>" name="first_name" value="<?php echo e(old('first_name')); ?>" >
                            <?php if($errors->has('first_name')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('first_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-5">
                        <label for="event_name"><?php echo e(__('SEARCH By Event_Name')); ?></label>
                            <input id="event_name" type="text" placeholder="Seach event_name " class="form-control<?php echo e($errors->has('event_name') ? ' is-invalid' : ''); ?>" name="event_name" value="<?php echo e(old('event_name')); ?>" >
                            <?php if($errors->has('event_name')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('event_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-2" style="margin-top: 23px;">
                       
                            <button type="submit" class="btn btn-lg btn-success">
                                <?php echo e(__('SEARCH')); ?>

                            </button>
                        </div>
                    </div>
                 </div>      
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>